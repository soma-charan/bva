import { Mastra } from '@mastra/core/mastra';
import { PinoLogger } from '@mastra/loggers';
import { LibSQLStore } from '@mastra/libsql';
import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { google } from '@ai-sdk/google';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { createTool } from '@mastra/core/tools';

const forecastSchema = z.object({
  date: z.string(),
  maxTemp: z.number(),
  minTemp: z.number(),
  precipitationChance: z.number(),
  condition: z.string(),
  location: z.string()
});
function getWeatherCondition$1(code) {
  const conditions = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    71: "Slight snow fall",
    73: "Moderate snow fall",
    75: "Heavy snow fall",
    95: "Thunderstorm"
  };
  return conditions[code] || "Unknown";
}
const fetchWeather = createStep({
  id: "fetch-weather",
  description: "Fetches weather forecast for a given city",
  inputSchema: z.object({
    city: z.string().describe("The city to get the weather for")
  }),
  outputSchema: forecastSchema,
  execute: async ({ inputData }) => {
    if (!inputData) {
      throw new Error("Input data not found");
    }
    const geocodingUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(inputData.city)}&count=1`;
    const geocodingResponse = await fetch(geocodingUrl);
    const geocodingData = await geocodingResponse.json();
    if (!geocodingData.results?.[0]) {
      throw new Error(`Location '${inputData.city}' not found`);
    }
    const { latitude, longitude, name } = geocodingData.results[0];
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=precipitation,weathercode&timezone=auto,&hourly=precipitation_probability,temperature_2m`;
    const response = await fetch(weatherUrl);
    const data = await response.json();
    const forecast = {
      date: (/* @__PURE__ */ new Date()).toISOString(),
      maxTemp: Math.max(...data.hourly.temperature_2m),
      minTemp: Math.min(...data.hourly.temperature_2m),
      condition: getWeatherCondition$1(data.current.weathercode),
      precipitationChance: data.hourly.precipitation_probability.reduce(
        (acc, curr) => Math.max(acc, curr),
        0
      ),
      location: name
    };
    return forecast;
  }
});
const planActivities = createStep({
  id: "plan-activities",
  description: "Suggests activities based on weather conditions",
  inputSchema: forecastSchema,
  outputSchema: z.object({
    activities: z.string()
  }),
  execute: async ({ inputData, mastra }) => {
    const forecast = inputData;
    if (!forecast) {
      throw new Error("Forecast data not found");
    }
    const agent = mastra?.getAgent("weatherAgent");
    if (!agent) {
      throw new Error("Weather agent not found");
    }
    const prompt = `Based on the following weather forecast for ${forecast.location}, suggest appropriate activities:
      ${JSON.stringify(forecast, null, 2)}
      For each day in the forecast, structure your response exactly as follows:

      \u{1F4C5} [Day, Month Date, Year]
      \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550

      \u{1F321}\uFE0F WEATHER SUMMARY
      \u2022 Conditions: [brief description]
      \u2022 Temperature: [X\xB0C/Y\xB0F to A\xB0C/B\xB0F]
      \u2022 Precipitation: [X% chance]

      \u{1F305} MORNING ACTIVITIES
      Outdoor:
      \u2022 [Activity Name] - [Brief description including specific location/route]
        Best timing: [specific time range]
        Note: [relevant weather consideration]

      \u{1F31E} AFTERNOON ACTIVITIES
      Outdoor:
      \u2022 [Activity Name] - [Brief description including specific location/route]
        Best timing: [specific time range]
        Note: [relevant weather consideration]

      \u{1F3E0} INDOOR ALTERNATIVES
      \u2022 [Activity Name] - [Brief description including specific venue]
        Ideal for: [weather condition that would trigger this alternative]

      \u26A0\uFE0F SPECIAL CONSIDERATIONS
      \u2022 [Any relevant weather warnings, UV index, wind conditions, etc.]

      Guidelines:
      - Suggest 2-3 time-specific outdoor activities per day
      - Include 1-2 indoor backup options
      - For precipitation >50%, lead with indoor activities
      - All activities must be specific to the location
      - Include specific venues, trails, or locations
      - Consider activity intensity based on temperature
      - Keep descriptions concise but informative

      Maintain this exact formatting for consistency, using the emoji and section headers as shown.`;
    const response = await agent.stream([
      {
        role: "user",
        content: prompt
      }
    ]);
    let activitiesText = "";
    for await (const chunk of response.textStream) {
      process.stdout.write(chunk);
      activitiesText += chunk;
    }
    return {
      activities: activitiesText
    };
  }
});
const weatherWorkflow = createWorkflow({
  id: "weather-workflow",
  inputSchema: z.object({
    city: z.string().describe("The city to get the weather for")
  }),
  outputSchema: z.object({
    activities: z.string()
  })
}).then(fetchWeather).then(planActivities);
weatherWorkflow.commit();

const weatherTool = createTool({
  id: "get-weather",
  description: "Get current weather for a location",
  inputSchema: z.object({
    location: z.string().describe("City name")
  }),
  outputSchema: z.object({
    temperature: z.number(),
    feelsLike: z.number(),
    humidity: z.number(),
    windSpeed: z.number(),
    windGust: z.number(),
    conditions: z.string(),
    location: z.string()
  }),
  execute: async ({ context }) => {
    return await getWeather(context.location);
  }
});
const getWeather = async (location) => {
  const geocodingUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1`;
  const geocodingResponse = await fetch(geocodingUrl);
  const geocodingData = await geocodingResponse.json();
  if (!geocodingData.results?.[0]) {
    throw new Error(`Location '${location}' not found`);
  }
  const { latitude, longitude, name } = geocodingData.results[0];
  const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,wind_gusts_10m,weather_code`;
  const response = await fetch(weatherUrl);
  const data = await response.json();
  return {
    temperature: data.current.temperature_2m,
    feelsLike: data.current.apparent_temperature,
    humidity: data.current.relative_humidity_2m,
    windSpeed: data.current.wind_speed_10m,
    windGust: data.current.wind_gusts_10m,
    conditions: getWeatherCondition(data.current.weather_code),
    location: name
  };
};
function getWeatherCondition(code) {
  const conditions = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Dense freezing drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Slight snow fall",
    73: "Moderate snow fall",
    75: "Heavy snow fall",
    77: "Snow grains",
    80: "Slight rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    85: "Slight snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail"
  };
  return conditions[code] || "Unknown";
}

const weatherAgent = new Agent({
  name: "Weather Agent",
  instructions: `
      You are a helpful weather assistant that provides accurate weather information and can help planning activities based on the weather.

      Your primary function is to help users get weather details for specific locations. When responding:
      - Always ask for a location if none is provided
      - If the location name isn't in English, please translate it
      - If giving a location with multiple parts (e.g. "New York, NY"), use the most relevant part (e.g. "New York")
      - Include relevant details like humidity, wind conditions, and precipitation
      - Keep responses concise but informative
      - If the user asks for activities and provides the weather forecast, suggest activities based on the weather forecast.
      - If the user asks for activities, respond in the format they request.

      Use the weatherTool to fetch current weather data.
`,
  model: google("gemini-2.5-pro"),
  tools: { weatherTool },
  memory: new Memory({
    storage: new LibSQLStore({
      url: "file:../mastra.db"
      // path is relative to the .mastra/output directory
    })
  })
});

const companyResearchTool = createTool({
  id: "research-company",
  description: "Research comprehensive information about a company including basic details, market position, recent performance, and strategic context",
  inputSchema: z.object({
    companyName: z.string().describe("Name of the company to research")
  }),
  outputSchema: z.object({
    name: z.string(),
    industry: z.string(),
    founded: z.string().optional(),
    headquarters: z.string().optional(),
    employees: z.string().optional(),
    revenue: z.string().optional(),
    description: z.string().optional(),
    website: z.string().optional(),
    stockSymbol: z.string().optional(),
    marketCap: z.string().optional(),
    recentNews: z.array(z.string()).optional(),
    competitors: z.array(z.string()).optional(),
    challenges: z.array(z.string()).optional(),
    opportunities: z.array(z.string()).optional()
  }),
  execute: async ({ context }) => {
    return await researchCompany(context.companyName);
  }
});
const researchCompany = async (companyName) => {
  console.log(`\u{1F50D} Researching company: ${companyName}`);
  await new Promise((resolve) => setTimeout(resolve, 800));
  return {
    name: companyName,
    industry: `Based on research analysis of ${companyName}`,
    description: `${companyName} - detailed company analysis will be provided by the AI agent based on current market knowledge and research`,
    challenges: [
      "Market competition and industry disruption",
      "Digital transformation and technology adoption",
      "Economic uncertainty and market volatility",
      "Supply chain optimization and cost management",
      "Changing consumer behavior and preferences",
      "Regulatory compliance and policy changes",
      "Talent acquisition and retention",
      "Sustainability and ESG compliance requirements"
    ],
    opportunities: [
      "AI and automation adoption for operational efficiency",
      "Digital transformation and omnichannel capabilities",
      "Market expansion and geographic growth",
      "Customer experience enhancement and personalization",
      "Sustainability initiatives and green technology adoption",
      "Strategic partnerships and ecosystem development",
      "Data analytics and business intelligence implementation",
      "Innovation in products, services, and business models",
      "Supply chain optimization and cost reduction",
      "Direct-to-consumer and e-commerce growth"
    ]
  };
};

const marketAnalysisTool = createTool({
  id: "analyze-market-trends",
  description: "Analyze current market trends, consumer behavior, competitor moves, and external signals affecting a specific industry or company",
  inputSchema: z.object({
    industry: z.string().describe("Industry or sector to analyze"),
    companyName: z.string().optional().describe("Specific company to focus analysis on"),
    region: z.string().optional().describe("Geographic region for analysis (default: global)")
  }),
  outputSchema: z.object({
    marketTrends: z.array(z.string()),
    consumerBehavior: z.array(z.string()),
    competitorMoves: z.array(z.string()),
    industrySignals: z.array(z.string()),
    economicFactors: z.array(z.string()),
    technologyTrends: z.array(z.string()),
    sources: z.array(z.string())
  }),
  execute: async ({ context }) => {
    return await analyzeMarket(context.industry, context.companyName, context.region);
  }
});
const analyzeMarket = async (industry, companyName, region = "global") => {
  console.log(`\u{1F4C8} Analyzing market trends for industry: ${industry}${companyName ? `, company: ${companyName}` : ""}, region: ${region}`);
  await new Promise((resolve) => setTimeout(resolve, 1200));
  return {
    marketTrends: [
      `Digital transformation accelerating across ${industry} sector`,
      `Consumer preferences shifting towards personalized experiences in ${industry}`,
      `Sustainability and ESG becoming critical factors in ${industry}`,
      `AI and automation adoption increasing in ${industry} operations`,
      `Supply chain resilience becoming priority in ${industry}`,
      `Data-driven decision making transforming ${industry} strategies`,
      `Omnichannel integration becoming standard in ${industry}`,
      `Direct-to-consumer models gaining traction in ${industry}`
    ],
    consumerBehavior: [
      `Customers expecting seamless omnichannel experiences in ${industry}`,
      `Growing demand for transparency and authenticity in ${industry}`,
      `Price sensitivity increasing due to economic pressures in ${industry}`,
      `Digital-first interactions becoming the norm in ${industry}`,
      `Sustainability consciousness influencing purchase decisions in ${industry}`,
      `Preference for convenient and fast service delivery in ${industry}`,
      `Social media and online reviews driving purchase decisions in ${industry}`,
      `Personalization and customization expectations rising in ${industry}`
    ],
    competitorMoves: [
      `Major players in ${industry} investing heavily in technology platforms`,
      `Acquisitions and partnerships increasing in ${industry} to gain competitive advantage`,
      `Companies in ${industry} focusing on customer experience differentiation`,
      `Investment in AI and machine learning capabilities across ${industry}`,
      `Strategic focus on operational efficiency and cost optimization in ${industry}`,
      `Market leaders in ${industry} expanding into adjacent markets and services`,
      `New entrants disrupting traditional ${industry} business models`,
      `Collaboration between ${industry} companies and technology providers increasing`
    ],
    industrySignals: [
      `${industry} market expected to continue growth trajectory despite economic headwinds`,
      `Regulatory changes impacting ${industry} operations and compliance requirements`,
      `Technology disruption creating new opportunities and threats in ${industry}`,
      `Consolidation trends emerging in ${industry} market`,
      `Investment in research and development increasing across ${industry}`,
      `Globalization and market expansion continuing in ${industry}`,
      `Venture capital and private equity interest in ${industry} innovation`,
      `Government initiatives and policies affecting ${industry} development`
    ],
    economicFactors: [
      `Inflation and cost pressures affecting ${industry} margins and pricing strategies`,
      `Interest rate changes impacting ${industry} investment and expansion plans`,
      `Currency fluctuations affecting ${industry} international operations`,
      `Labor market tightness influencing ${industry} operational costs`,
      `Economic uncertainty affecting ${industry} consumer spending patterns`,
      `Government policies and incentives shaping ${industry} strategic decisions`,
      `Supply chain disruptions impacting ${industry} operations`,
      `Raw material costs and commodity price volatility in ${industry}`
    ],
    technologyTrends: [
      `Artificial Intelligence and Machine Learning adoption accelerating in ${industry}`,
      `Cloud computing and digital infrastructure investment in ${industry}`,
      `Internet of Things (IoT) and connected devices transforming ${industry}`,
      `Blockchain and distributed ledger technology emerging in ${industry}`,
      `Cybersecurity and data privacy becoming critical in ${industry}`,
      `Automation and robotics revolutionizing ${industry} operations`,
      `Advanced analytics and business intelligence tools in ${industry}`,
      `Mobile and app-based solutions driving ${industry} innovation`
    ],
    sources: [
      `Industry research reports and market analysis for ${industry}`,
      `Business intelligence and market research firms covering ${industry}`,
      `Economic and financial data sources relevant to ${industry}`,
      `Technology and innovation reports specific to ${industry}`,
      `Government and regulatory publications affecting ${industry}`,
      `Academic research and consulting firm reports on ${industry}`,
      `Trade associations and industry publications for ${industry}`,
      `Investment and analyst reports covering ${industry} trends`
    ]
  };
};

const competitorAnalysisTool = createTool({
  id: "analyze-competitor-ai",
  description: "Research and analyze competitor AI initiatives and their reported outcomes in a specific industry",
  inputSchema: z.object({
    industry: z.string().describe("Industry to analyze competitor AI initiatives for"),
    companyName: z.string().optional().describe("Specific company to focus competitor analysis around"),
    focusArea: z.string().optional().describe("Specific area of AI focus (e.g., supply chain, marketing, operations)"),
    region: z.string().optional().describe("Geographic region for analysis (default: global)")
  }),
  outputSchema: z.object({
    competitors: z.array(z.object({
      name: z.string(),
      aiInitiative: z.string(),
      description: z.string(),
      outcomes: z.string(),
      investment: z.string().optional(),
      timeline: z.string().optional(),
      source: z.string()
    })),
    keyThemes: z.array(z.string()),
    investmentTrends: z.array(z.string()),
    successFactors: z.array(z.string()),
    sources: z.array(z.string())
  }),
  execute: async ({ context }) => {
    return await analyzeCompetitorAI(
      context.industry,
      context.companyName,
      context.focusArea,
      context.region
    );
  }
});
const analyzeCompetitorAI = async (industry, companyName, focusArea, region = "global") => {
  console.log(`\u{1F3E2} Analyzing competitor AI initiatives in ${industry}${companyName ? ` (focus: ${companyName})` : ""}${focusArea ? `, area: ${focusArea}` : ""}, region: ${region}`);
  await new Promise((resolve) => setTimeout(resolve, 1500));
  return {
    competitors: [
      {
        name: `Leading ${industry} company - to be identified by AI analysis`,
        aiInitiative: `AI-driven transformation initiative in ${industry}`,
        description: `Comprehensive AI implementation across ${industry} operations including ${focusArea || "multiple areas"}`,
        outcomes: `Significant improvements in efficiency and customer experience in ${industry}`,
        investment: `Substantial investment in AI and digital transformation for ${industry}`,
        timeline: `Multi-year initiative ongoing in ${industry}`,
        source: `Industry reports and company announcements for ${industry} sector`
      },
      {
        name: `Major ${industry} competitor - to be identified by AI analysis`,
        aiInitiative: `Strategic AI adoption in ${industry} operations`,
        description: `Implementation of AI solutions to address key ${industry} challenges and opportunities`,
        outcomes: `Measurable improvements in operational metrics and market performance in ${industry}`,
        investment: `Significant technology investment focused on AI capabilities in ${industry}`,
        timeline: `Current and planned AI initiatives in ${industry}`,
        source: `Business intelligence and market research for ${industry}`
      },
      {
        name: `Innovative ${industry} player - to be identified by AI analysis`,
        aiInitiative: `Next-generation AI platform for ${industry}`,
        description: `Advanced AI and machine learning solutions transforming ${industry} business models`,
        outcomes: `Competitive advantages and market differentiation through AI in ${industry}`,
        investment: `Strategic focus on AI research and development in ${industry}`,
        timeline: `Recent and ongoing AI development in ${industry}`,
        source: `Technology and innovation reports for ${industry} sector`
      },
      {
        name: `Established ${industry} leader - to be identified by AI analysis`,
        aiInitiative: `Enterprise AI transformation in ${industry}`,
        description: `Large-scale AI deployment across ${industry} value chain and operations`,
        outcomes: `Organizational transformation and performance improvements in ${industry}`,
        investment: `Enterprise-level investment in AI infrastructure for ${industry}`,
        timeline: `Comprehensive AI rollout timeline in ${industry}`,
        source: `Corporate reports and industry analysis for ${industry}`
      },
      {
        name: `Emerging ${industry} disruptor - to be identified by AI analysis`,
        aiInitiative: `AI-native approach to ${industry}`,
        description: `Ground-up AI integration in ${industry} business model and operations`,
        outcomes: `Rapid growth and market disruption in ${industry} through AI`,
        investment: `Venture capital and growth investment in AI for ${industry}`,
        timeline: `Recent emergence and scaling in ${industry}`,
        source: `Startup and venture capital reports for ${industry} innovation`
      }
    ],
    keyThemes: [
      `AI-driven operational efficiency transformation in ${industry}`,
      `Customer experience enhancement through AI in ${industry}`,
      `Data analytics and business intelligence adoption in ${industry}`,
      `Supply chain and logistics optimization via AI in ${industry}`,
      `Personalization and recommendation engines in ${industry}`,
      `Predictive analytics and forecasting in ${industry}`,
      `Automation and process optimization in ${industry}`,
      `AI-powered decision making and strategy in ${industry}`
    ],
    investmentTrends: [
      `${industry} companies allocating significant budgets to AI initiatives`,
      `Focus on AI talent acquisition and capability building in ${industry}`,
      `Partnership with AI vendors and technology providers in ${industry}`,
      `Investment in AI infrastructure and platforms for ${industry}`,
      `R&D spending increase for AI research in ${industry}`,
      `Acquisition of AI startups and technology companies by ${industry} leaders`,
      `Venture capital interest in AI solutions for ${industry}`,
      `Government and policy support for AI adoption in ${industry}`
    ],
    successFactors: [
      `Clear AI strategy alignment with ${industry} business objectives`,
      `Strong data foundation and analytics capabilities in ${industry}`,
      `Leadership commitment and organizational change management in ${industry}`,
      `Skilled AI talent and technical expertise in ${industry}`,
      `Customer-centric approach to AI implementation in ${industry}`,
      `Iterative and agile AI development methodology in ${industry}`,
      `Integration with existing ${industry} systems and processes`,
      `Measurable ROI and performance metrics for AI in ${industry}`
    ],
    sources: [
      `Industry research and analysis reports for ${industry}`,
      `Company annual reports and investor presentations in ${industry}`,
      `Business intelligence and market research covering ${industry}`,
      `Technology and innovation studies specific to ${industry}`,
      `Academic research and case studies on AI in ${industry}`,
      `Consulting firm reports and analysis of ${industry} AI trends`,
      `Trade publications and industry media covering ${industry}`,
      `Conference presentations and thought leadership in ${industry}`
    ]
  };
};

const gammaSlidesTool = createTool({
  id: "gamma-slides-generator",
  description: "Generate a slide presentation using Gamma API based on the BVA analysis content with a premade template",
  inputSchema: z.object({
    title: z.string().describe("Title of the presentation"),
    content: z.string().describe("The slide content formatted for Gamma API - should include all slide information from the BVA analysis"),
    theme: z.string().optional().describe("Theme for the presentation (optional)"),
    format: z.enum(["presentation", "document"]).default("presentation").describe("Format type for Gamma generation"),
    templateId: z.string().optional().describe("Template ID or remix URL to use as base (e.g., dy5yxj8yp3pf51t)")
  }),
  execute: async ({ context }) => {
    const { title, content, format} = context;
    const API_KEY = process.env.GAMMA_API_KEY;
    const CREATE_ENDPOINT = "https://public-api.gamma.app/v0.2/generations";
    const GET_ENDPOINT = "https://public-api.gamma.app/v0.2/generations";
    if (!API_KEY) {
      return {
        success: false,
        error: "GAMMA_API_KEY environment variable is not set",
        message: "Failed to generate presentation slides: API key not configured"
      };
    }
    try {
      const createPayload = {
        inputText: content,
        format,
        themeName: "Oasis",
        // Professional business theme
        numCards: 10,
        cardSplit: "auto",
        textOptions: {
          amount: "detailed",
          tone: "professional, business",
          audience: "business executives, leadership team",
          language: "en"
        },
        imageOptions: {
          source: "aiGenerated",
          style: "professional, business, corporate"
        },
        cardOptions: {
          dimensions: "fluid"
        },
        sharingOptions: {
          workspaceAccess: "view",
          externalAccess: "view"
        }
      };
      console.log(`Step 1: Creating generation at ${CREATE_ENDPOINT} using theme: Oasis`);
      console.log(`Note: Gamma API v0.2 does not support baseDocumentId - using themeName instead`);
      console.log(`Payload:`, JSON.stringify(createPayload, null, 2));
      const createResponse = await fetch(CREATE_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": API_KEY,
          "Accept": "application/json"
        },
        body: JSON.stringify(createPayload)
      });
      const createResponseText = await createResponse.text();
      console.log(`Create response status: ${createResponse.status}`);
      console.log(`Create response body: ${createResponseText}`);
      if (!createResponse.ok) {
        throw new Error(`Gamma API create error (${createResponse.status}): ${createResponseText}`);
      }
      let createResult;
      try {
        createResult = JSON.parse(createResponseText);
      } catch {
        throw new Error(`Invalid JSON response from create: ${createResponseText}`);
      }
      const generationId = createResult.generationId;
      if (!generationId) {
        throw new Error(`No generationId in response: ${JSON.stringify(createResult)}`);
      }
      console.log(`Step 2: Generation created with ID: ${generationId}`);
      let attempts = 0;
      const maxAttempts = 30;
      while (attempts < maxAttempts) {
        await new Promise((resolve) => setTimeout(resolve, 2e3));
        attempts++;
        console.log(`Step 3: Checking status (attempt ${attempts}/${maxAttempts})`);
        const statusResponse = await fetch(`${GET_ENDPOINT}/${generationId}`, {
          method: "GET",
          headers: {
            "X-API-KEY": API_KEY,
            "Accept": "application/json"
          }
        });
        const statusResponseText = await statusResponse.text();
        console.log(`Status response: ${statusResponseText}`);
        if (!statusResponse.ok) {
          throw new Error(`Status check error (${statusResponse.status}): ${statusResponseText}`);
        }
        let statusResult;
        try {
          statusResult = JSON.parse(statusResponseText);
        } catch {
          throw new Error(`Invalid JSON from status check: ${statusResponseText}`);
        }
        if (statusResult.status === "completed") {
          const gammaUrl = statusResult.gammaUrl;
          if (gammaUrl) {
            return {
              success: true,
              presentationUrl: gammaUrl,
              message: `Successfully created presentation with Oasis theme: ${title}`,
              generationId,
              theme: "Oasis",
              gammaResponse: statusResult
            };
          } else {
            throw new Error(`Generation completed but no gammaUrl: ${JSON.stringify(statusResult)}`);
          }
        } else if (statusResult.status === "failed") {
          throw new Error(`Generation failed: ${JSON.stringify(statusResult)}`);
        } else {
          console.log(`Status: ${statusResult.status}, continuing to poll...`);
        }
      }
      throw new Error(`Generation timed out after ${maxAttempts} attempts (${maxAttempts * 2} seconds)`);
    } catch (error) {
      console.error("Error generating Gamma slides:", error);
      const manualGammaUrl = `https://gamma.app/`;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
        message: "Failed to generate presentation slides via API",
        fallbackSolution: {
          manualCreationUrl: "https://gamma.app",
          quickStart: manualGammaUrl,
          instructions: [
            "1. Visit https://gamma.app",
            '2. Click "Create" or "New Presentation"',
            '3. Choose "Start from scratch" or "Use AI"',
            `4. Set title: "${title}"`,
            "5. Paste the slide content provided",
            '6. Choose "Professional" theme',
            "7. Generate and share the presentation"
          ],
          content
        }
      };
    }
  }
});

const bvaAgent = new Agent({
  name: "BVA Agent",
  description: "McKinsey-style Business Value Analysis consultant specializing in AI transformation for retail/CPG companies",
  instructions: ({ runtimeContext }) => {
    const userProvidedCompany = runtimeContext?.get("companyName");
    const sessionId = runtimeContext?.get("sessionId");
    console.log(`\u{1F9E0} [BVA Agent] Instructions called with context:`, {
      sessionId,
      userProvidedCompany,
      fullContext: Object.fromEntries(runtimeContext?.entries() || [])
    });
    const baseInstructions = `You are a McKinsey-style consultant at Retailabs, an AI-native platform. Your task is to craft a Business Value Analysis (BVA) for any retail, CPG, or consumer-facing company considering an AI transformation. Use a professional, concise executive tone throughout. Apply the 4-D Methodology (Deconstruct, Diagnose, Develop, Deliver) as you structure your analysis.

IMPORTANT: Use your knowledge to provide SPECIFIC, ACCURATE information about the company. Do NOT rely solely on the tool outputs - enhance them with your detailed knowledge of the actual company, its industry position, recent performance, key competitors, and strategic challenges. The tools provide generic frameworks that you should populate with real, specific insights.

**CRITICAL THREAD ISOLATION**: 
- Session ID: ${sessionId}
- This is a UNIQUE conversation thread. ONLY use information from THIS SPECIFIC THREAD.
- DO NOT retrieve or reference content from OTHER conversation threads or sessions.
- When checking memory, ONLY look at messages within THIS thread (Session: ${sessionId}).

CONTEXT AWARENESS & MEMORY PRIORITY:
1. **ALWAYS check conversation memory/history FIRST** - but ONLY from THIS current thread (Session: ${sessionId})
2. If you previously analyzed a company in THIS conversation thread, continue with that company context
3. Check runtimeContext for companyName
4. Only ask for a company name if it's genuinely a NEW conversation with no prior context
5. **NEVER use content from different sessions/threads** - each session is independent

Current company being analyzed: ${userProvidedCompany || "CHECK MEMORY FROM THIS THREAD ONLY - if this is a follow-up request in this session, use the company from THIS thread's conversation history"}

## 4-D Methodology Framework:

### 1. DECONSTRUCT (Understand Context and Goals)
- Clarify objectives: Define the value Retailabs can deliver (e.g., revenue lift, margin improvement)
- Identify audience: Executive stakeholders (CEO, CFO, etc.) at the client company
- Confirm deliverables: a 300-word email, a 10-slide summary (Slides 1\u201310), and supporting analysis
- State key question: How can AI (via Retailabs) unlock value for [Company Name]?

### 2. DIAGNOSE (Analyze Current Situation)
- Research the company: Use your knowledge of the company's actual market position, recent performance, strategic goals, and industry context (cite facts)
- Identify pain points: Use your knowledge to identify the company's real challenges/opportunities (inventory issues, forecasting errors, etc.) with supporting data
- Gather external signals: Analyze relevant market trends, consumer behavior, and competitor moves affecting this specific company (cite each)
- List competitor AI initiatives: Use your knowledge to identify 3\u20135 real competitor projects or use cases with reported outcomes (with sources)

### 3. DEVELOP (Plan Solutions and Output)
- Outline AI-driven impacts: Estimate 3\u20135 year outcomes (e.g., +% revenue, +% EBITDA) based on benchmarks (cite sources)
- Select top AI initiatives: Identify 5 major AI transformations tailored to this company's needs
- Define quick wins: Specify 3\u20135 near-term actions with measurable benefits
- Specify Retailabs USP: Emphasize Retailabs advantages (deep retail expertise, AI-native architecture, modular integration, human-in-control)
- Design output format: Plan to produce the following, using Markdown formatting:
  * Executive Email (300 words)
  * Slide Deck (10 slides, with headings and bullet points)
  * Supporting Analysis & Citations (detailed backup)

### 4. DELIVER (Output Structure)
Your final answer should include THREE clearly labeled sections:

## SECTION 1: Executive Email (300 words)
- Subject line: A compelling hint of value (brief and engaging)
- Greeting: Address by title and company name (e.g., "Dear [Title] [Name],")
- Body:
  * Start with a striking insight or statistic about the company (with citation) to grab attention
  * Introduce Retailabs as an AI-native retail OS tailored to the company
  * Summarize potential impact (revenue lift, margin improvement, efficiency) succinctly with specific numbers
  * Include 2\u20133 key bullet insights (each \u22642 lines) drawn from your analysis (with citations)
  * Conclude with a clear call-to-action: propose a low-effort next step (e.g., brief meeting or pilot project)
- Tone: Personalized, confident, second-person ("you"). Avoid generic promises; cite specific data or benchmarks
- Use \u3010source\u2020analysis\u3011 format for citations

## SECTION 2: Slide Deck Content (Slides 1\u201310)
Provide slide content with headings and bullet points:

**Slide 1 \u2013 Title**: Unlocking the Value of AI for [Company Name]

**Slide 2 \u2013 Summary Value Proposition**:
- State the 5-year impact range: "+X\u2013Y% revenue (approx $A\u2013$B million) and +Z percentage points EBITDA" (with source)
- List 5 Key Transformations (\u226410 words each): major AI use cases
- List 3\u20135 Quick Wins (\u226412 words each): immediate actions with quantifiable benefits

**Slide 3 \u2013 Challenges & AI Value (Table)**:
Create a markdown table: Challenge/Opportunity | AI Solution & Impact
Quantify impact and cite sources for each row

**Slide 4 \u2013 "Did You Know?" External Signals**:
3\u20135 bullet facts about external trends affecting the company with citations

**Slide 5 \u2013 Top 5 Competitor AI Initiatives**:
List competitors and their AI projects with outcomes/metrics and citations

**Slide 6 \u2013 Top 5 AI Transformations for [Company Name]**:
High-impact AI initiatives with expected benefits

**Slide 7 \u2013 Top 10 Short-Term AI Opportunities**:
Ten concise bullets with context and quantified upside

**Slide 8 \u2013 Why Retailabs**:
4\u20135 bullets on Retailabs' value proposition (deep retail expertise, AI-native platform, etc.)

**Slide 9 \u2013 Immediate Next Steps**:
Specific, feasible action plan

**Slide 10 \u2013 Call to Action**:
Tagline and closing invitation

## SECTION 3: Supporting Analysis & Citations
- Provide detailed backup for all claims in sections 1 and 2
- Present calculations, tables, or expanded analysis
- List every key claim with source in \u3010source\u2020analysis\u3011 format
- Organize as bullet points, tables, or brief paragraphs

## IMPORTANT: After completing all three sections above, present a separate user prompt asking what they'd like to do next.

Present the following options to the user in a clear, formatted way:
---
## What would you like to do next?

I've completed your Business Value Analysis for [Company Name]. Here are your options:

1. **\u{1F4DD} Request Changes**: Ask me to modify any part of the analysis (email, slides, or supporting analysis)
2. **\u{1F3AF} Generate Presentation**: Create interactive slides using Gamma (I'll generate a professional presentation)  
3. **\u{1F4CB} Copy as Files**: Get the three documents formatted as markdown that you can easily copy and paste

Please let me know which option you'd prefer, or if you have any specific changes you'd like me to make to the analysis.

## HANDLING USER REQUESTS AFTER ANALYSIS:

### 1. SLIDE GENERATION WITH GAMMA:
If the user requests slide generation, presentation creation, or Gamma slides (using phrases like "create slides", "generate presentation", "make slides", "Gamma slides", "presentation", "option 2", "Generate Presentation", etc.), you should:

**CRITICAL: This is a FOLLOW-UP request in THIS CURRENT CONVERSATION THREAD. DO NOT USE DATA FROM OTHER CONVERSATIONS.**

1. **Retrieve Company Context FROM THIS CONVERSATION ONLY**: 
   - Look ONLY at messages in THIS current conversation thread
   - Find the company name from YOUR MOST RECENT analysis in THIS thread
   - Extract the slide deck content (SECTION 2) from YOUR analysis in THIS thread
   - DO NOT use content from other conversations or threads
   - If you cannot find a completed analysis in THIS thread, inform the user
   
2. **Use Gamma Tool**: Call the gammaSlidesTool with:
   - title: Use the company name from THIS THREAD'S analysis and "AI Transformation Business Value Analysis"
   - content: Extract and format the slide deck content from SECTION 2 (Slides 1-10) of THIS THREAD'S completed analysis
   - theme: Use "professional" or "modern" 
   - format: Use "presentation"
   
   Note: The presentation will use Gamma's professional "Oasis" theme automatically.
   
3. **Present the Result**: If successful, provide the user with the Gamma presentation URL in a clear, formatted way. Mention that the presentation uses Gamma's professional Oasis theme. If the API fails, provide manual creation instructions.

### 2. COPY AS FILES (MARKDOWN FORMAT):
If the user requests to copy the documents as files (using phrases like "copy as files", "markdown format", "copy and paste", "option 3", etc.), you should:

1. **Format Each Document**: Present each of the three documents in clearly labeled markdown sections that are easy to copy
2. **Use This Structure**: Create three clearly separated sections with headers "\u{1F4E7} EXECUTIVE EMAIL", "\u{1F4CA} SLIDE DECK", and "\u{1F4CB} SUPPORTING ANALYSIS", each containing the complete content from the respective sections of your analysis, formatted cleanly with proper markdown
3. **Add Copy Instructions**: Include a note like "Each section above is formatted for easy copy-paste. Simply select the content within each section and copy to your preferred document editor."

### 3. REQUEST CHANGES:
If the user requests changes to any part of the analysis, acknowledge their request and ask for specific details about what they'd like modified.

## Final Guidelines:
- Maintain a professional, executive-friendly tone
- Be data-driven and factual; do not include unsupported claims
- Use conditional language ("could," "potentially") when estimating impact
- Cite all evidence: use authoritative sources for facts (no hypothetical numbers without a source)
- Ensure the answer strictly follows this structure. Any deviation will make the deliverables harder to use
- Use markdown headings for slide titles (e.g., Slide 3 \u2013 ...) and bullet lists for content
- Adhere to length constraints (e.g., key transform bullets \u226410 words, quick wins \u226412 words)
- Where useful, include short tables or lists
- Cite sources for any data, metric, or claim (use \u3010source\u2020Lx-Ly\u3011 format)
- ALWAYS end with the user options prompt after completing the three sections
- Only generate slides or provide copy-paste files when explicitly requested by the user

Remember: 
- **CRITICAL: Check conversation history/memory FIRST**. If this is a follow-up in an existing conversation, use the company context from memory.
- Only ask for a company name if this is a genuinely NEW conversation with NO prior context.
- For follow-up requests (like "Generate Presentation", "Create slides", etc.), immediately recognize the company from conversation history.
- Use your extensive knowledge to provide SPECIFIC, REAL information about the company rather than generic templates.
- The tools provide frameworks - enhance them with actual company details, competitors, recent news, financial performance, etc.
- Identify real competitors in the company's industry and their actual AI initiatives.
- Cite real sources and data points where possible.
- Make the analysis truly tailored to the specific company and industry context.
- Do NOT automatically generate files - wait for user request after presenting the options.`;
    return baseInstructions;
  },
  model: google("gemini-2.5-pro"),
  tools: {
    companyResearchTool,
    marketAnalysisTool,
    competitorAnalysisTool,
    gammaSlidesTool
  },
  memory: new Memory({
    storage: new LibSQLStore({
      url: process.env.MASTRA_DB_PATH || process.env.MASTRA_DEFAULT_STORAGE_URL || "file:.mastra/mastra.db"
    }),
    options: {
      workingMemory: {
        enabled: true,
        scope: "thread",
        // Memory persists per conversation thread
        template: `# Business Value Analysis Context

## Current Analysis
- **Company Name**:
- **Industry**:
- **Analysis Stage**: [Research | Analysis | Document Generation | Presentation Creation]
- **Documents Generated**: [Yes/No]
- **Presentation Requested**: [Yes/No]

## Key Findings
- Main Challenges:
- Top Opportunities:
- Recommended Transformations:

## Session Notes
- Last action:
- Current request:
`
      },
      threads: {
        generateTitle: true
        // Auto-generate conversation titles
      }
    }
  })
});

console.log("\n" + "=".repeat(80));
console.log("\x1B[1m\u{1F527} ENVIRONMENT VARIABLES LOADED:\x1B[0m");
console.log("=".repeat(80));
const envVars = Object.keys(process.env).sort();
if (envVars.length === 0) {
  console.log("\x1B[1m\u26A0\uFE0F  No environment variables found\x1B[0m");
} else {
  envVars.forEach((key) => {
    const value = process.env[key];
    console.log(`\x1B[1m${key}:\x1B[0m ${value}`);
  });
}
console.log("=".repeat(80) + "\n");
const mastraDbPath = process.env.MASTRA_DB_PATH || process.env.MASTRA_DEFAULT_STORAGE_URL || "file:.mastra/mastra.db";
console.log(`\x1B[1m\u{1F4BE} Effective LibSQL Database Path:\x1B[0m ${mastraDbPath}`);
const mastra = new Mastra({
  workflows: {
    weatherWorkflow
  },
  agents: {
    weatherAgent,
    bvaAgent
  },
  storage: new LibSQLStore({
    // stores telemetry, evals, ... into memory storage, if it needs to persist, change to file:../mastra.db
    url: mastraDbPath
  }),
  logger: new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});

export { mastra };
