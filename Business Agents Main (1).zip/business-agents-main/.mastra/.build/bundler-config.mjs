const bundler = {};

export { bundler };
